# -*- coding: utf-8 -*-
"""
Finite element model for an Euler-Bernoulli beam.

@author: Vincent Mahé
"""

import numpy as np
from typing import TYPE_CHECKING

from ..beam.beam import Beam


class FEMModel:
    r"""
    Finite element model of an Euler-Bernoulli beam.

    The beam is discretised into ``ne`` elements of equal length.
    Each node has two degrees of freedom: transverse displacement :math:`v` and rotation :math:`\theta`. The global stiffness matrix :math:`\mathbf{K}` and mass matrix :math:`\mathbf{M}` are assembled using the standard Hermite shape functions.

    Parameters
    ----------
    beam : Beam
        The beam to model.
    ne : int
        Number of finite elements.

    Examples
    --------
    >>> from beamsolve.beam import Beam, rectangular_section
    >>> from beamsolve.FEM import FEMModel
    >>> A, I = rectangular_section(b=0.02, h=0.005)
    >>> beam = Beam(L=1.0, E=210e9, rho=7800, A=A, I=I,
    ...             bc_left="clamped", bc_right="free")
    >>> model = FEMModel(beam=beam, ne=20)
    """

    if TYPE_CHECKING:
        beam       : Beam
        ne         : int
        n_nodes    : int
        n_dof      : int
        Le         : float
        K          : "np.ndarray"
        M          : "np.ndarray"

    def __init__(self, beam: Beam, ne: int = 20):
        self.beam       = beam
        self.ne         = ne
        self.n_nodes    = ne + 1
        self.n_dof      = 2 * self.n_nodes
        self.Le         = beam.L / ne

        # Elementary matrices
        Ke = self.element_stiffness()
        Me = self.element_mass()

        # Global matrices
        Kg = self.assemble_global_matrix(Ke)
        Mg = self.assemble_global_matrix(Me)

        # Reduced matrices
        self.K, self.M = self.reduced_matrices(Kg, Mg)

    # ── Private methods ────────────────────────────────────────────────────────

    def element_stiffness(self) -> np.ndarray:
        r"""
        Return the 4 by 4 Euler-Bernoulli element stiffness matrix.

        .. math::
            \mathbf{k}_e = \frac{EI}{\ell_e^3}
            \begin{bmatrix}
             12       &  6\ell_e    & -12      &  6\ell_e    \\
              6\ell_e &  4\ell_e^2  & -6\ell_e &  2\ell_e^2  \\
            -12       & -6\ell_e    &  12      & -6\ell_e    \\
              6\ell_e &  2\ell_e^2  & -6\ell_e &  4\ell_e^2
            \end{bmatrix}
        """
        E, I, Le = self.beam.E, self.beam.I, self.Le
        Ke = E * I / Le**3 * np.array([
            [ 12,      6*Le,    -12,      6*Le   ],
            [  6*Le,   4*Le**2,  -6*Le,   2*Le**2],
            [-12,     -6*Le,     12,     -6*Le   ],
            [  6*Le,   2*Le**2,  -6*Le,   4*Le**2],
        ])

        return Ke

    def element_mass(self) -> np.ndarray:
        r"""
        Return the 4 by 4 mass matrix.

        .. math::
            \mathbf{m}_e = \frac{\rho A \ell_e}{420}
            \begin{bmatrix}
             156      &  22\ell_e   &  54       & -13\ell_e   \\
             22\ell_e &  4\ell_e^2  &  13\ell_e & -3\ell_e^2  \\
             54       &  13\ell_e   & 156       & -22\ell_e   \\
            -13\ell_e & -3\ell_e^2  & -22\ell_e &  4\ell_e^2
            \end{bmatrix}
        """
        rho, A, Le = self.beam.rho, self.beam.A, self.Le
        Me = rho * A * Le / 420 * np.array([
            [ 156,      22*Le,     54,      -13*Le   ],
            [  22*Le,    4*Le**2,  13*Le,    -3*Le**2],
            [  54,      13*Le,    156,      -22*Le   ],
            [ -13*Le,   -3*Le**2, -22*Le,    4*Le**2 ],
        ])
        return Me

    def assemble_global_matrix(self, Me) -> np.ndarray:
        r"""
        Assemble the global finite element (mass or stiffness) matrix.

        Parameters
        ----------
        Me: np.ndarray
            The elementary matrix to be assembled.
        """
        
        # Initialisation
        M = np.zeros((self.n_dof, self.n_dof))

        # Build the global matrix
        for e in range(self.ne):
            dofs = [2*e, 2*e+1, 2*e+2, 2*e+3]
            for i, di in enumerate(dofs):
                for j, dj in enumerate(dofs):
                    M[di, dj] += Me[i, j]

        return M

    def get_constrained_dofs(self) -> list:
        r"""
        Return the list of constrained degrees of freedom based on the beam
        boundary conditions.

        Returns
        -------
        constrained : list of int
            Indices of the constrained DOFs.
        """

        # Build a constraints mapping
        constrained = []
        bc_map = {
            "clamped" : [True, True],   # v=0, theta=0
            "pinned"  : [True, False],  # v=0, theta free
            "free"    : [False, False], # unconstrained
        }

        # Left end: node 0 → DOFs 0, 1
        fix_v, fix_t = bc_map[self.beam.bc_left]
        if fix_v: constrained.append(0)
        if fix_t: constrained.append(1)

        # Right end: node n_nodes-1 → DOFs 2*(n_nodes-1), 2*(n_nodes-1)+1
        last = 2 * (self.n_nodes - 1)
        fix_v, fix_t = bc_map[self.beam.bc_right]
        if fix_v: constrained.append(last)
        if fix_t: constrained.append(last + 1)

        return constrained

    def get_free_dofs(self):
        r"""
        Get the unconstrained dof
        """

        constrained = self.get_constrained_dofs()
        free_dofs   = [d for d in range(self.n_dof) if d not in constrained]

        return free_dofs

    def reduced_matrices(self, Kg, Mg):
        r"""
        Build the reduced stiffness and mass matrices from the global one and the constraints.
        
        Parameters
        ----------
        Kg: np.ndarray
            The global stiffness matrix.

        Mg: np.ndarray
            The global mss matrix.
        """

        # Get the unconstraint dof
        free_dofs = self.get_free_dofs()

        # Build the reduced matrices
        Kr = Kg[np.ix_(free_dofs, free_dofs)]
        Mr = Mg[np.ix_(free_dofs, free_dofs)]

        return Kr, Mr