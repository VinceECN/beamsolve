# -*- coding: utf-8 -*-
"""
Modal solver for the Euler-Bernoulli beam FEM model.

@author: Vincent Mahé
"""

import numpy as np
import scipy.linalg as slg
from typing import List, TYPE_CHECKING

from .fem_model import FEMModel


class FEMSolution:
    r"""
    Modal solution of the beam FEM model.

    Attributes
    ----------
    frequencies : numpy.ndarray
        Natural frequencies [Hz], shape ``(n_modes,)``, sorted in ascending
        order.
    omega : numpy.ndarray
        Angular natural frequencies [rad/s], shape ``(n_modes,)``.
    Phi : numpy.ndarray
        Normalised mode shapes, shape ``(n_nodes, n_modes)``. Each column is
        a mode shape evaluated at the beam nodes. Normalisation: the
        component with the largest absolute value is 1, and the first
        non-negligible component is positive.
    x_nodes : numpy.ndarray
        Nodal positions along the beam [m], shape ``(n_nodes,)``.
    """

    if TYPE_CHECKING:
        frequencies : "np.ndarray"
        omegas      : "np.ndarray"
        Phi         : "np.ndarray"
        x_nodes     : "np.ndarray"

    def __init__(self, frequencies, omegas, Phi, x_nodes):
        self.frequencies = frequencies
        self.omegas      = omegas
        self.Phi         = Phi
        self.x_nodes     = x_nodes


def _normalise(phi: np.ndarray) -> np.ndarray:
    r"""
    Normalise a mode shape vector.

    The component with the largest absolute value is set to 1.
    If the first non-negligible component is negative, the vector is flipped.

    Parameters
    ----------
    phi : numpy.ndarray
        Raw eigenvector.

    Returns
    -------
    phi_norm : numpy.ndarray
        Normalised mode shape.
    """
    phi = phi / np.max(np.abs(phi))

    # Find first non-negligible component and flip if negative
    threshold = 1e-6
    for val in phi:
        if np.abs(val) > threshold:
            if val < 0:
                phi = -phi
            break

    return phi


def solve_modes(model: FEMModel, n_modes: int = 5) -> FEMSolution:
    r"""
    Solve the generalised eigenvalue problem and return the modal solution.

    The free degrees of freedom are extracted from the global matrices based
    on the beam boundary conditions, and the following problem is solved:

    .. math::
        \mathbf{K}_{\mathrm{free}} \, \boldsymbol{\phi} =
        \omega^2 \, \mathbf{M}_{\mathrm{free}} \, \boldsymbol{\phi}.

    Parameters
    ----------
    model : FEMModel
        The assembled FEM model.
    n_modes : int, optional
        Number of modes to compute. Default is 5.

    Returns
    -------
    sol : FEMSolution
        The modal solution.

    Examples
    --------
    >>> from beamsolve.beam import Beam, rectangular_section
    >>> from beamsolve.FEM import FEMModel, solve_modes
    >>> A, I = rectangular_section(b=0.02, h=0.005)
    >>> beam  = Beam(L=1.0, E=210e9, rho=7800, A=A, I=I,
    ...              bc_left="clamped", bc_right="free")
    >>> model = FEMModel(beam=beam, ne=20)
    >>> sol   = solve_modes(model, n_modes=3)
    """

    # Solve generalised eigenvalue problem
    eigvals, eigvecs = slg.eigh(model.K, b=model.M)

    # Sort by ascending frequency
    sort_idx = np.argsort(eigvals)
    eigvals  = eigvals[sort_idx]
    eigvecs  = eigvecs[:, sort_idx]

    # Keep only the requested number of modes
    eigvals  = eigvals[:n_modes]
    eigvecs = eigvecs[:, :n_modes]

    omegas      = np.sqrt(eigvals)
    frequencies = omegas / (2 * np.pi)

    # Expand eigenvectors back to full DOF space (zeros at constrained DOFs)
    free_dofs = model.get_free_dofs()
    n_nodes   = model.n_nodes
    Phi       = np.zeros((n_nodes, n_modes))

    for k in range(n_modes):
        phi_full = np.zeros(model.n_dof)
        for i, d in enumerate(free_dofs):
            phi_full[d] = eigvecs[i, k]

        # Extract displacement DOFs only (even indices)
        phi_v    = phi_full[0::2]
        Phi[:, k] = _normalise(phi_v)

    x_nodes = np.linspace(0, model.beam.L, n_nodes)

    return FEMSolution(
        frequencies = frequencies,
        omegas      = omegas,
        Phi         = Phi,
        x_nodes     = x_nodes,
    )
