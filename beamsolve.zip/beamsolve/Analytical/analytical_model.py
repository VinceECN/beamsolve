# -*- coding: utf-8 -*-
"""
Analytical modal analysis of the Euler-Bernoulli beam.

@author: [Author name]
"""

import numpy as np
from scipy.optimize import brentq
from typing import TYPE_CHECKING

from ..beam.beam import Beam


class AnalyticalModel:
    r"""
    Analytical modal analysis of an Euler-Bernoulli beam.

    The natural frequencies and mode shapes are computed from the analytical
    solution of the Euler-Bernoulli beam equation

    .. math::
        EI \frac{\partial^4 V}{\partial x^4} - \rho A \omega^2 V = 0.

    The general solution for the mode shape :math:`V(x)` is

    .. math::
        V(x) = C_1 \cos(\beta x) + C_2 \sin(\beta x)
              + C_3 \cosh(\beta x) + C_4 \sinh(\beta x),

    where the wavenumber :math:`\beta` is related to the angular frequency by

    .. math::
        \beta^4 = \frac{\rho A \omega^2}{EI}.

    The boundary conditions at both ends are gathered in a :math:`4 \times 4`
    matrix :math:`Z(\beta)` such that :math:`Z(\beta)\,\mathbf{C} = \mathbf{0}`.
    Natural frequencies correspond to values of :math:`\beta` for which
    :math:`\det Z(\beta) = 0`. The associated mode shape coefficients
    :math:`\mathbf{C}` are obtained as the null vector of :math:`Z(\beta)` via SVD.

    The rows of :math:`Z(\beta)` encode the following conditions:

    - **Clamped** end: :math:`V = 0` and :math:`V' = 0`
    - **Pinned** end: :math:`V = 0` and :math:`V'' = 0`
    - **Free** end: :math:`V'' = 0` and :math:`V''' = 0`

    Parameters
    ----------
    beam : Beam
        The beam to analyse.
    n_modes : int
        Number of modes to compute.

    Examples
    --------
    >>> from beamsolve.beam import Beam, rectangular_section
    >>> from beamsolve.Analytical import AnalyticalModel
    >>> A, I = rectangular_section(b=0.02, h=0.005)
    >>> beam  = Beam(L=1.0, E=210e9, rho=7800, A=A, I=I,
    ...              bc_left="clamped", bc_right="free")
    >>> model = AnalyticalModel(beam=beam, n_modes=3)
    >>> model.frequencies
    array([...])
    """

    if TYPE_CHECKING:
        beam        : Beam
        n_modes     : int
        frequencies : "np.ndarray"
        omegas      : "np.ndarray"
        betas       : "np.ndarray"

    def __init__(self, beam: Beam, n_modes: int = 5):
        self.beam    = beam
        self.n_modes = n_modes

        self.betas       = self.find_betas()
        self.omegas      = self.betas**2 * np.sqrt(beam.E * beam.I / (beam.rho * beam.A))
        self.frequencies = self.omegas / (2 * np.pi)

    # ── BC matrix ─────────────────────────────────────────────────────────────

    def bc_rows(self, bc: str, x: float, beta: float) -> np.ndarray:
        r"""
        Return the two rows of :math:`Z(\beta)` corresponding to boundary
        condition ``bc`` applied at position ``x``.

        The mode shape :math:`V(x) = C_1\cos + C_2\sin + C_3\cosh + C_4\sinh`
        and its derivatives evaluated at ``x`` give the following rows:

        .. math::
            V    &: [\cos,\ \sin,\ \cosh,\ \sinh] \\
            V'   &: \beta\,[-\sin,\ \cos,\ \sinh,\ \cosh] \\
            V''  &: \beta^2\,[-\cos,\ -\sin,\ \cosh,\ \sinh] \\
            V''' &: \beta^3\,[\sin,\ -\cos,\ \sinh,\ \cosh]

        Parameters
        ----------
        bc : str
            Boundary condition type (``"clamped"``, ``"pinned"``, ``"free"``).
        x : float
            Position [m] where the BC is applied.
        beta : float
            Wavenumber [1/m].

        Returns
        -------
        rows : numpy.ndarray, shape (2, 4)
            Two rows of the BC matrix.
        """
        bx       = beta * x
        co, si   = np.cos(bx),  np.sin(bx)
        ch, sh   = np.cosh(bx), np.sinh(bx)
        b, b2, b3 = beta, beta**2, beta**3

        row_V   = np.array([ co,     si,     ch,    sh  ])
        row_dV  = np.array([-b*si,   b*co,   b*sh,  b*ch])
        row_d2V = np.array([-b2*co, -b2*si,  b2*ch, b2*sh])
        row_d3V = np.array([ b3*si, -b3*co,  b3*sh, b3*ch])

        if bc == "clamped":
            return np.array([row_V,   row_dV ])   # V=0,   V'=0
        elif bc == "pinned":
            return np.array([row_V,   row_d2V])   # V=0,   V''=0
        elif bc == "free":
            return np.array([row_d2V, row_d3V])   # V''=0, V'''=0

    def build_Z(self, beta: float) -> np.ndarray:
        r"""
        Assemble the :math:`4 \times 4` boundary condition matrix
        :math:`Z(\beta)`.

        Parameters
        ----------
        beta : float
            Wavenumber [1/m].

        Returns
        -------
        Z : numpy.ndarray, shape (4, 4)
        """
        rows_left  = self.bc_rows(self.beam.bc_left,  0,           beta)
        rows_right = self.bc_rows(self.beam.bc_right, self.beam.L, beta)
        return np.vstack([rows_left, rows_right])

    def characteristic_equation(self, beta: float) -> float:
        r"""
        Evaluate the characteristic equation :math:`\det Z(\beta)`.

        To avoid numerical overflow from the hyperbolic functions at large
        :math:`\beta L`, the determinant is normalised by the Frobenius norm
        of :math:`Z`:

        .. math::
            f(\beta) = \frac{\det Z(\beta)}{\| Z(\beta) \|_F^4}

        Parameters
        ----------
        beta : float
            Wavenumber [1/m].

        Returns
        -------
        float
            Value of the normalised characteristic equation.
        """
        Z    = self.build_Z(beta)
        norm = np.linalg.norm(Z, ord='fro')
        if norm == 0:
            return 0.0
        return np.linalg.det(Z) / norm**4

    # ── Root finding ──────────────────────────────────────────────────────────

    def find_betas(self) -> np.ndarray:
        r"""
        Find the first ``n_modes`` roots of :math:`\det Z(\beta) = 0` by
        scanning for sign changes and refining with Brent's method.

        Returns
        -------
        betas : numpy.ndarray
            Array of wavenumbers :math:`\beta` [1/m], shape ``(n_modes,)``.
        """
        n_scan    = 10000
        betaL_max = (self.n_modes + 2) * np.pi
        beta_arr  = np.linspace(0.01, betaL_max / self.beam.L, n_scan)

        f_arr = np.array([self.characteristic_equation(b) for b in beta_arr])
        roots = []

        for i in range(len(f_arr) - 1):
            if f_arr[i] * f_arr[i + 1] < 0:
                try:
                    root = brentq(
                        self.characteristic_equation,
                        beta_arr[i], beta_arr[i + 1],
                        xtol=1e-12,
                    )
                    roots.append(root)
                except ValueError:
                    pass
            if len(roots) == self.n_modes:
                break

        if len(roots) < self.n_modes:
            raise RuntimeError(
                f"Only {len(roots)} roots found out of {self.n_modes} requested. "
                "Try increasing the scan range."
            )

        return np.array(roots[:self.n_modes])

    # ── Mode shapes ───────────────────────────────────────────────────────────

    def mode_coefficients(self, beta: float) -> np.ndarray:
        r"""
        Compute the mode shape coefficients :math:`\mathbf{C} = [C_1, C_2, C_3, C_4]`
        for a given wavenumber via SVD of :math:`Z(\beta)`.

        At a root :math:`\beta_i`, :math:`Z(\beta_i)` has rank 3 and its
        smallest singular value is (numerically) zero. The associated right
        singular vector — the last row of :math:`V^T` in the decomposition
        :math:`Z = U \Sigma V^T` — spans the null space and gives
        :math:`\mathbf{C}`.

        Parameters
        ----------
        beta : float
            Wavenumber [1/m].

        Returns
        -------
        C : numpy.ndarray, shape (4,)
            Mode shape coefficients :math:`[C_1, C_2, C_3, C_4]`.
        """
        Z        = self.build_Z(beta)
        _, _, Vt = np.linalg.svd(Z)
        return Vt[-1]

    def phi(self, x: np.ndarray, beta: float) -> np.ndarray:
        r"""
        Evaluate the mode shape at positions ``x``.

        Parameters
        ----------
        x : numpy.ndarray
            Positions along the beam [m].
        beta : float
            Wavenumber [1/m].

        Returns
        -------
        phi : numpy.ndarray
            Mode shape values at positions ``x``.
        """
        C1, C2, C3, C4 = self.mode_coefficients(beta)
        return (
              C1 * np.cos (beta * x)
            + C2 * np.sin (beta * x)
            + C3 * np.cosh(beta * x)
            + C4 * np.sinh(beta * x)
        )

    def normalise(self, phi: np.ndarray) -> np.ndarray:
        r"""
        Normalise a mode shape vector.

        The component with the largest absolute value is set to 1. If the
        first non-negligible component is negative, the vector is flipped.
        """
        phi = phi / np.max(np.abs(phi))
        for val in phi:
            if np.abs(val) > 1e-6:
                if val < 0:
                    phi = -phi
                break
        return phi

    def evaluate(self, x: np.ndarray) -> np.ndarray:
        r"""
        Evaluate all mode shapes on a spatial grid.

        Parameters
        ----------
        x : numpy.ndarray
            Positions along the beam [m], shape ``(n_points,)``.

        Returns
        -------
        mode_shapes : numpy.ndarray
            Normalised mode shapes, shape ``(n_points, n_modes)``.
            Each column corresponds to one mode.

        Examples
        --------
        >>> import numpy as np
        >>> from beamsolve.beam import Beam, rectangular_section
        >>> from beamsolve.Analytical import AnalyticalModel
        >>> A, I = rectangular_section(b=0.02, h=0.005)
        >>> beam  = Beam(L=1.0, E=210e9, rho=7800, A=A, I=I,
        ...              bc_left="clamped", bc_right="free")
        >>> model = AnalyticalModel(beam=beam, n_modes=3)
        >>> x     = np.linspace(0, beam.L, 200)
        >>> phi   = model.evaluate(x)
        >>> phi.shape
        (200, 3)
        """
        Phi = np.zeros((len(x), self.n_modes))
        for k, beta in enumerate(self.betas):
            Phi[:, k] = self.normalise(self.phi(x, beta))
        return Phi
