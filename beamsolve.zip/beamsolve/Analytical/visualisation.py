# -*- coding: utf-8 -*-
"""
Visualisation utilities for analytical modal solutions.

@author: [Author name]
"""

import numpy as np
import matplotlib.pyplot as plt

from .analytical_model import AnalyticalModel


def plot_mode_shapes(
    model     : AnalyticalModel,
    fig       : plt.Figure = None,
    n_points  : int  = 300,
    modes     : list = None,
    save_path : str  = None,
):
    r"""
    Plot the analytical transverse mode shapes of the beam.

    Parameters
    ----------
    model : AnalyticalModel
        The analytical model.
    fig: Figure
        The figure where to plot the mode shapes.
    n_points : int, optional
        Number of points used to evaluate the mode shapes. Default is 300.
    modes : list of int, optional
        Indices of the modes to plot (0-indexed). If None, all modes are
        plotted.
    save_path : str, optional
        If provided, the figure is saved at this path instead of displayed.

    Examples
    --------
    >>> from beamsolve.beam import Beam, rectangular_section
    >>> from beamsolve.Analytical import AnalyticalModel, visualisation
    >>> A, I = rectangular_section(b=0.02, h=0.005)
    >>> beam  = Beam(L=1.0, E=210e9, rho=7800, A=A, I=I,
    ...              bc_left="clamped", bc_right="free")
    >>> model = AnalyticalModel(beam=beam, n_modes=3)
    >>> visualisation.plot_mode_shapes(model)
    """
    if modes is None:
        modes = list(range(model.n_modes))

    x   = np.linspace(0, model.beam.L, n_points)
    Phi = model.evaluate(x)

    n_plots = len(modes)
    if fig is None:
        fig, axes = plt.subplots(1, n_plots, figsize=(4 * n_plots, 4), sharey=False)
        if n_plots == 1:
            axes = [axes]

        for ax, k in zip(axes, modes):
            ax.plot(x, Phi[:, k], color="tab:pink", linewidth=2)
            ax.set_xlabel("$x$ [m]")
            ax.set_ylabel("Normalised displacement")
            ax.set_title(
                f"Mode {k+1} (analytical)\n$f_{k+1}$ = {model.frequencies[k]:.2f} Hz"
            )
            ax.grid(True, linestyle=":", alpha=0.6)

        fig.tight_layout()

    else:
        axes = fig.get_axes()
        for ax, k in zip(axes, modes):
            ax.get_lines()[-1].set_label("FEM")
            ax.plot(x, Phi[:, k], color="tab:pink", linewidth=2, label="analytical")
            ax.legend()
    
    if save_path is not None:
        fig.savefig(save_path)
        print(f"Figure saved to {save_path}")
    else:
        plt.show()

    return fig, axes
